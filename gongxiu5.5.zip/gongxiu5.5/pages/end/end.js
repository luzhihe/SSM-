
//获取应用实例
const app = getApp()

Page({
  data: {
    targetNumber:"",
    status:"",
    userNumber:"",
    dayDown:"",
    myNumber:"",
    realNumber:"",
    userId:"",
    groupId:"",
    //分页
    // 前台显示list
    sonlist: [],
    // 当前页
    pageNumber: 1,
    // 总页数
    totalPage: '',

  },
  // 分享
  onShareAppMessage: function () {
    return {
      title: '一起来参加共修',
      desc: '共修活动',
      path: '/page/index?id=123',
    }
  },
  onLoad: function (options) {
    var that = this;
    //共修活动简介
    app.globalData.aeHttp({
      url: "MeditationSchedule",
      data: {
        "cmd": "findMscheduleByGroupId",
        "data": {
          "openId": app.globalData.openid,
          "scheduleId": options.id,
          "openGId": app.globalData.openGId,
        },
        "header": {
          "appname": "慧修行",
          "platform": app.globalData.platform,
          "v": app.globalData.v,
        }
      }
    },
      function (res) {
        console.log(res.data.data);
        that.setData({
          targetNumber: res.data.data.targetNumber,//目标数
          status: res.data.data.status,   //完成状态
          userNumber: res.data.data.userNumber,//参与人数
          realNumber: res.data.data.realNumber,//总共完成数
          myNumber: res.data.data.myNumber,   //我完成的遍数
          dayDown: res.data.data.dayDown,   //坚持天数
          userId: res.data.data.userId

        })
      },
      function (err) {
        console.log(err);
      });
    // 排行榜
    app.globalData.aeHttp({
      url: "MeditationTask",
      data: {
        "cmd": "findMeditationTask",
        "data": {
          "openId": app.globalData.openid,
          "scheduleId": options.id,
          "pageNumber":1,
          "openGId": app.globalData.openGId,
        },
        "header": {
          "appname": "慧修行",
          "platform": app.globalData.platform,
          "v": app.globalData.v,
        }
      }
    }, 
    function (res) {
      console.log(res);
      that.setData({
        list: res.data.data.list,
        totalPage: res.data.data.totalPage,
        openGId: res.data.data.openGId,
      })
    },
     function (err) {
      console.log(err)
    });
    // 我的排名
    app.globalData.aeHttp({
      url: "MeditationTask",
      data: {
        "cmd": "findMysort",
        "data": {
          "openId": app.globalData.openid,
          "scheduleId": options.id,
          // "pageNumber": 1,
          "openGId": app.globalData.openGId,
        },
        "header": {
          "appname": "慧修行",
          "platform": app.globalData.platform,
          "v": app.globalData.v,
        }
      }
    },
      function (res) {
        console.log(res.data)

        that.setData({
          map: res.data.data,
          // openGId: res.data.data.openGId,
        })
        // console.log(map)
      },
      function (err) {
        console.log(err)
      })
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this;
    console.log(that)
    // 当前页+1
    var pageNumber = that.data.pageNumber + 1;
    that.setData({
      pageNumber: pageNumber,
    })
    if (pageNumber <= that.data.totalPage) {
      wx.showLoading({
        title: '加载中',
      })
      // 请求后台，获取下一页的数据。
      app.globalData.aeHttp({
        url: "MeditationTask",
        data: {
          "cmd": "findMeditationTask",
          "data": {
            "openId": app.globalData.openid,
            "scheduleId": that.data.scheduleId,
            "pageNumber": pageNumber,
            "openGId":res.data.data.openGId,
          },
          "header": {
            "appname": "慧修行",
            "platform": app.globalData.platform,
            "v": app.globalData.v,
          }
        }
      },
        function (res) {
          wx.hideLoading()
          // 将新获取的数据 res.data.list，concat到前台显示的showlist中即可。
          that.setData({
            // sonlist: res.data.data,
            list: that.data.list.concat(res.data.data.list)
          })
        },
        function (err) {
          console.log(err)
        })
    }
    if (pageNumber > that.data.totalPage) {
      wx.showLoading({
        title: '全部已加载',
      }),
        setTimeout(function () {
          wx.hideLoading()
        }, 400)
    }
  },
  // 下拉刷新回调接口
  onPullDownRefresh: function () {
    // do somthing
    console.log("调用下拉刷新回调接口成功。。。")
    wx.stopPullDownRefresh();
  },
})
