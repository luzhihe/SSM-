//logs.js
// const util = require('../../utils/util.js')

//获取应用实例
const app = getApp()
Page({
  data: {
    scheduleId: "",
    userNumber: "",//参加人数
    scheduleIntro: "",//信息简介
    targetNumber: "",//总共的遍数
    activeTitle: "",//共修名称
    dayDown: "",//距离结束还有多少天
    realNumber: "",//已完成多少遍
    percent: "",//完成数量百分比
    todayNumber:"",
    userId:"",
    //分页
    // 前台显示list
    sonlist: [],
    // 当前页
    pageNumber: 1,
    // 总页数
    totalPage: '',
  },
  // 分享
  onShareAppMessage: function () {
    var that = this;
    console.log(that.data.scheduleId)
    console.log("分享")
    return {
      withShareTicket: true,
      title: '一起来参加共修',
      desc: '共修活动',
      path: '/pages/details/details?id=' + that.data.scheduleId,
    }
  },
  onLoad: function (options) {
    console.log(options)
    var that = this;
    that.setData({
      scheduleId: options.id
    });
    app.globalData.aeHttp({
      url: "MeditationSchedule",
      data: {
        "cmd": "findMscheduleBySId",
        "data": {
          "scheduleId": options.id,
          "openId": app.globalData.openid,
        },
        "header": {
          "appname": "慧修行",
          "platform": app.globalData.platform,
          "v": app.globalData.v,
        }
      }
    },
      function (res) {
        console.log(res.data.data);
        that.setData({
          // title: res.data.data.meditationTypeName,
          userNumber: res.data.data.userNumber,          //参加人数
           mesg: res.data.data.scheduleIntro,       //简介
           targetNumber: res.data.data.targetNumber,//总共的遍数
           activeTitle: res.data.data.activeTitle,//共修名称
           dayDown: res.data.data.dayDown,//距离结束还有多少天
           realNumber: res.data.data.realNumber,//已完成多少遍
           percent: res.data.data.percent,//完成数量百分比
           todayNumber:res.data.data.todayNumber,//今日上报数
           userId: res.data.data.userId,
        })
      },
      function (err) {
        console.log(err);
      });
    // 排行榜
    app.globalData.aeHttp({
      url: "MeditationTask",
      data: {
        "cmd": "findMeditationTask",
        "data": {
          "openId": app.globalData.openid,
          "scheduleId": options.id,
          "pageNumber": 1,
          "openGId":app.globalData.openGId,
        },
        "header": {
          "appname": "慧修行",
          "platform": app.globalData.platform,
          "v": app.globalData.v,
        }
      }
    },
     function (res) {
       console.log("res.data.data.openGId+++++++++")
       console.log(res.data.data)
      that.setData({
        list: res.data.data.list,
        totalPage: res.data.data.totalPage,
        openGId: res.data.data.openGId,
      })
    }, 
    function (err) {
      console.log(err)
    });
    // 我的排名
    app.globalData.aeHttp({
      url: "MeditationTask",
      data: {
        "cmd": "findMysort",
        "data": {
          "openId": app.globalData.openid,
          "scheduleId": options.id,
          // "pageNumber": 1,
          "openGId": app.globalData.openGId,
        },
        "header": {
          "appname": "慧修行",
          "platform": app.globalData.platform,
          "v": app.globalData.v,
        }
      }
    },
      function (res) {
        console.log(res.data)
        
        that.setData({
          map: res.data.data,
          // openGId: res.data.data.openGId,
        })
        // console.log(map)
      },
      function (err) {
        console.log(err)
      })
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this;
    console.log(that)
    // 当前页+1
    var pageNumber = that.data.pageNumber + 1;

    that.setData({
      pageNumber: pageNumber,
    })
    console.log(that.data.totalPage);
    if (pageNumber <= that.data.totalPage) {
      wx.showLoading({
        title: '加载中',
      })
      // 请求后台，获取下一页的数据。
      app.globalData.aeHttp({
        url: "MeditationTask",
        data: {
          "cmd": "findMeditationTask",
          "data": {
            "openId": app.globalData.openid,
            "scheduleId": that.data.scheduleId,
            "pageNumber": pageNumber,
          },
          "header": {
            "appname": "慧修行",
            "platform": app.globalData.platform,
            "v": app.globalData.v,
          }
        }
      },
        function (res) {
          wx.hideLoading()
          // 将新获取的数据 res.data.list，concat到前台显示的showlist中即可。
          console.log(res);
          console.log(res.data.data)
          that.setData({
            // sonlist: res.data.data,
            list: that.data.list.concat(res.data.data.list)
          })
        },
        function (err) {
          console.log(err)
        })
    }
    if (pageNumber > that.data.totalPage) {
      wx.showLoading({
        title: '全部已加载',
      }),
        setTimeout(function () {
          wx.hideLoading()
        }, 400)
    }
  },
  // 下拉刷新回调接口
  onPullDownRefresh: function () {
    // do somthing
    console.log("调用下拉刷新回调接口成功。。。")
    wx.stopPullDownRefresh();
  },
  onShow: function (options){
    if (options.scene == 1044) {
      console.log("我是微信群里进来的，快来取我啊！！！")
      }
  }
})
