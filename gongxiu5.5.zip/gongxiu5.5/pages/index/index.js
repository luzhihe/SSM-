//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
    flag:false,
    scheduleId: "", 
    openId:"",
    //分页
    // 前台显示list
    sonlist: [],
    // 当前页
    pageNumber: 1,
    // 总页数
    totalPage: '',
  },
  // 分享
  onShareAppMessage: function () {
    return {
      title: '一起来参加共修',
      desc: '共修活动',
      path: '/pages/index/index?id=123',
    }
  },

  onLoad: function (opt) {
    wx.showShareMenu({
        withShareTicket: true
         })
    wx.showLoading({
      title: '加载中...',
    })
    console.log("我是onload...")
    
    var that = this;
    console.log(that)
    if (app.globalData.openid && app.globalData.openid != '') {
      that.setData({
        openId:app.globalData.openid
      })
      console.log("第一次就成功获得openid")
      app.globalData.aeHttp({
        url: "MeditationSchedule",
        data: {
          "cmd": "findMschedule",
          "data": {
            "openId": that.data.openId,
            "pageNumber": 1,
          },
          "header": {
            "appname": "慧修行",
            "platform": app.globalData.platform,
            "v": app.globalData.v,
          }
        }
      },
        function (res) {
          that.setData({
            sonlist: res.data.data.schedules,
            totalPage: res.data.data.totalPage,
            openId: app.globalData.openid
          })
        },
        function (err) {
          console.log(err);
        });
      // 我参加的共修
      app.globalData.aeHttp({
        url: "MeditationSchedule",
        data: {
          "cmd": "findMscheduleByUserId",
          "data": {
            "openId": that.data.openId,
          },
          "header": {
            "appname": "慧修行",
            "platform": app.globalData.platform,
            "v": app.globalData.v,
          }
        }
      },
        function (res) {
          console.log(res);
          console.log(res.data.data)
          that.setData({
            addlist: res.data.data
          })
          if (res.data.data) {
            setTimeout(function () {
              wx.hideLoading();
            }, 500)
          }
        },
        function (err) {
          console.log(err)
        })
    } else{
      app.requestReadyCallback = res =>{
        if (res != '') {
        that.setData({
          openId: res.data.data,
        })
        console.log(res.data.data)
        console.log(that.data.openId)
        console.log("第二次就成功获得openid" + that.data.openId)
        app.globalData.aeHttp({
          url: "MeditationSchedule",
          data: {
            "cmd": "findMschedule",
            "data": {
              "openId": that.data.openId,
              "pageNumber": 1,
            },
            "header": {
              "appname": "慧修行",
              "platform": app.globalData.platform,
              "v": app.globalData.v,
            }
          }
        },
          function (res) {
            that.setData({
              sonlist: res.data.data.schedules,
              totalPage: res.data.data.totalPage,
              openId: app.globalData.openid
            })
          },
          function (err) {
            console.log(err);
          });
        // 我参加的共修
        app.globalData.aeHttp({
          url: "MeditationSchedule",
          data: {
            "cmd": "findMscheduleByUserId",
            "data": {
              "openId": that.data.openId,
            },
            "header": {
              "appname": "慧修行",
              "platform": app.globalData.platform,
              "v": app.globalData.v,
            }
          }
        },
          function (res) {
            console.log(res);
            console.log(res.data.data)
            that.setData({
              addlist: res.data.data
            })
            if (res.data.data) {
              setTimeout(function () {
                wx.hideLoading()
              },500)
            }
          },
          function (err) {
            console.log(err)
          })
        }

      }
     
    }
    
   
    console.log(that.data)
    console.log("第3次就成功获得openid" + that.data.openId)
    console.log("我是onload...success")
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this;
    console.log(that)
    // 当前页+1
    var pageNumber = that.data.pageNumber + 1;

    that.setData({
      pageNumber: pageNumber,
    })
    console.log(that.data.totalPage);
    if (pageNumber<=that.data.totalPage) {
      wx.showLoading({
        title: '加载中',
      })
      // 请求后台，获取下一页的数据。
      app.globalData.aeHttp({
        url: "MeditationSchedule",
        data: {
          "cmd": "findMschedule",
          "data": {
            "openId": app.globalData.openid,
            "pageNumber": pageNumber,
          },
          "header": {
            "appname": "慧修行",
            "platform": app.globalData.platform,
            "v": app.globalData.v,
          }
      }
      },
        function(res) {
          wx.hideLoading()
          // 将新获取的数据 res.data.list，concat到前台显示的showlist中即可。
          console.log(res);
          console.log(res.data.data)
          that.setData({
            // sonlist: res.data.data,
            sonlist: that.data.sonlist.concat(res.data.data.schedules)
          })
        },
        function(err) {
          console.log(err)
      })
    }
    if ( pageNumber>that.data.totalPage) {
      wx.showLoading({
        title: '全部已加载',
      }),
        setTimeout(function () {
          wx.hideLoading()
        }, 400)
      }
  },
  // 下拉刷新回调接口
  onPullDownRefresh: function () {
    // wx.startPullDownRefresh();
    console.log("调用下拉刷新回调接口成功。。。")
    this.onLoad();
    wx.stopPullDownRefresh();
    wx.showToast({
      title: '刷新成功',
      icon: 'success',
      duration: 1000
    })
  },
  onShow: function (){
    this.onLoad();
    },
})
