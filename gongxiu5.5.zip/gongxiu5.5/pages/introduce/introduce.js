//logs.js
// const util = require('../../utils/util.js')
//获取应用实例
const app = getApp()
Page({
  data: {
    scheduleId:"",
    title:"",//标题
    pepl:"",//参加人数
    mesg:"",//信息简介
    targetNumber:"",//总共的遍数
    activeTitle:"",//遍数下面的介绍
    dayDown:"",//距离结束还有多少天
    realNumber:"",//已完成多少遍
    percent:"",//完成数量百分比
  },
  onLoad: function (options) {
    var that = this;
    console.log(options.id);
    that.setData({
      scheduleId: options.id
    });
    app.globalData.aeHttp({
      url: "MeditationSchedule",
      data: {
        "cmd": "findMscheduleById",
        "data": {
          "scheduleId": options.id,
        },
        "header": {
          "appname": "慧修行",
          "platform": app.globalData.platform,
          "v": app.globalData.v,
        }
      }
    },
      function (res) {
        console.log(res);
        console.log(res.data.data);
        that.setData({
          title:res.data.data.meditationTypeName,
          pepl: res.data.data.userNumber,
          mesg: res.data.data.scheduleIntro,
          targetNumber: res.data.data.targetNumber,//总共的遍数
          activeTitle: res.data.data.activeTitle,//遍数下面的介绍
          dayDown: res.data.data.dayDown,//距离结束还有多少天
          realNumber: res.data.data.realNumber,//已完成多少遍
          percent: res.data.data.percent,//完成数量百分比
        })
      },
      function (err) {
        console.log(err);
      }); 
  },
  bottom: function () {
    var that = this;
    console.log(this);
    app.globalData.aeHttp({
      url: "MeditationSchedule",
      data: {
        "cmd": "insertMeditationRecord",
        "data": {
          "scheduleId":that.data.scheduleId,
          "openId": app.globalData.openid,
        },
        "header": {
          "appname": "慧修行",
          "platform": app.globalData.platform,
          "v": app.globalData.v,
        }
      }
    },
    function (res){
      wx.showToast({
        title: res.data.message,
        icon: 'succes',
        duration: 2000,
        mask: true
      })
       console.log("sss"+res.data.message)
    },
    function(err){
      console.log(err)
    });
  },
  // 下拉刷新回调接口
  onPullDownRefresh: function () {
    // do somthing
    // wx.startPullDownRefresh();
    console.log("调用下拉刷新回调接口成功。。。")
    wx.stopPullDownRefresh();
  },
})

