
//logs.js
// const util = require('../../utils/util.js')

//获取应用实例
const app = getApp()
Page({
  data: {
    todayNumber: "",
    message:"",
    scheduleId:"",
    showok: function () {
      wx.showToast({
        title: '成功',
        icon: 'success',
        duration: 400
      })
    }  
  },
  //共修报数
  formSubmit: function (e) {
    var count = e.detail.value.count;
    var id = e.detail.value.id;
    console.log("ssssswwww");
    if (count>0){
      console.log(e);
      app.globalData.aeHttp({
        url: "CountRecord",
        data: {
          "cmd": "insertAllCount",
          "data": {
            "scheduleId": id,
            "openId": app.globalData.openid,
            "count": count,
          },
          "header": {
            "appname": "慧修行",
            "platform": app.globalData.platform,
            "v": app.globalData.v,
          }
        }
      },
        function (res) {
          wx.showToast({
            title: res.data.message,
            icon: 'succes',
            duration: 1000,
            mask: true
          }),
            //获取共修ID
            id = e.detail.value.id,
            wx.redirectTo({
              url: '../details/details?id=' + id,
            })
          message: res.data.message
        },
        function (err) {
          console.log(err);
        });
    }else{
      wx.showModal({
        title: '温馨提示',
        content: '共修报数不能小于零',
        success: function (res) {
        }
      })
    }
  
  },
  //今日上报数
  onLoad: function (options) {
    var that = this;
    console.log(options.id);
    that.setData({
      scheduleId: options.id
    });
    app.globalData.aeHttp({
      url: "MeditationSchedule",
      data: {
        "cmd": "findMscheduleBySId",
        "data": {
          "scheduleId": options.id,
          "openId": app.globalData.openid,
        },
        "header": {
          "appname": "慧修行",
          "platform": app.globalData.platform,
          "v": app.globalData.v,
        }
      }
    },
      function (res) {
        that.setData({
          todayNumber: res.data.data.todayNumber,//今日上报数
          userId: res.data.data.userId,
          scheduleId: res.data.data.scheduleId,
        })
      },
      function (err) {
        console.log(err);
      });
  },
  // 下拉刷新回调接口
  onPullDownRefresh: function () {
    // do somthing
    // wx.startPullDownRefresh();
    console.log("调用下拉刷新回调接口成功。。。")
    wx.stopPullDownRefresh();
  },
})

