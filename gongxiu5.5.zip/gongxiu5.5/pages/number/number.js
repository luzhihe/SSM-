
//logs.js
// const util = require('../../utils/util.js')

//获取应用实例
const app = getApp()
Page({
  data: {
    //分页
    // 前台显示list
    // 当前页
    pageNumber: 1,
    // 总页数
    totalPage: '',
  },
  onLoad: function (options) {
    var that = this;
    console.log(options.id);
    that.setData({
      scheduleId: options.id
    });
    app.globalData.aeHttp({
      url: "CountRecord",
      data: {
        "cmd": "findAllCountRecord",
        "data": {
          "openId": app.globalData.openid,
          "scheduleId": options.id,
          "pageNumber":1,
        },
        "header": {
          "appname": "慧修行",
          "platform": app.globalData.platform,
          "v": app.globalData.v,
        }
      }
    }, 
    function (res) {
      console.log(res);
      console.log(res.data.data)
      that.setData({
        countList: res.data.data.list,
         totalPage: res.data.data.totalPage,
         msg:res.data.data.msg
      })
    }, 
    function (err) {
      console.log(err)
    })
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this;
    console.log(that)
    // 当前页+1
    var pageNumber = that.data.pageNumber + 1;

    that.setData({
      pageNumber: pageNumber,
    })
    console.log(that.data.totalPage);
    if (pageNumber <= that.data.totalPage) {
      wx.showLoading({
        title: '加载中',
      })
      // 请求后台，获取下一页的数据。
      app.globalData.aeHttp({
        url: "CountRecord",
        data: {
          "cmd": "findAllCountRecord",
          "data": {
            "openId": app.globalData.openid,
            "scheduleId": that.data.scheduleId,
            "pageNumber": pageNumber,
          },
          "header": {
            "appname": "慧修行",
            "platform": app.globalData.platform,
            "v": app.globalData.v,
          }
        }
      },
        function (res) {
          wx.hideLoading()
          // 将新获取的数据 res.data.list，concat到前台显示的showlist中即可。
          console.log(res);
          console.log(res.data.data)
          that.setData({
            // sonlist: res.data.data,
            countList: that.data.countList.concat(res.data.data.list)
          })
        },
        function (err) {
          console.log(err)
        })
    }
    if (pageNumber > that.data.totalPage) {
      wx.showLoading({
        title: '全部已加载',
      }),
        setTimeout(function () {
          wx.hideLoading()
        }, 400)
    }
  },
  // 下拉刷新回调接口
  onPullDownRefresh: function () {
    // do somthing
    // wx.startPullDownRefresh();
    console.log("调用下拉刷新回调接口成功。。。")
    wx.stopPullDownRefresh();
  },
})

