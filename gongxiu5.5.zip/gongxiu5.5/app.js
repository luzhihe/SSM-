//app.js
App({
  data:{
     openId:"",
  },
  onShow: function (ops) {
    console.log("onLaunch....")
    var that = this;
    var openid="";//openid
    var nickName="";//姓名
    var avatarUrl = "";//头像
    var province="";//地区
    var platform="";//设备号
    var v="";//手机版本号
    var sex="";//性别
    var sessionkey=""; 
      wx.login({
        success: function (res) {
          //获取设备信息
          wx.getSystemInfo({
            success: function(res) {
              platform = res.system;
              that.globalData.platform = res.system;
              v=res.version;
              that.globalData.v = res.version;
            },
          })
          if (res.code) {
          
            //获取openId
            wx.request({
              url: 'https://www.everglamming.com/hrym-wechat-web/hrym/program/getSessionkey',
              // url: 'http://192.168.1.160:8080/hrym/program/getSessionkey',
              data: {
                "data": {
                  "jscode": res.code
                },
                "header": {
                  "appname": "慧修行",
                  "platform": platform,
                  "v": v
                }
              },
              method: 'POST',
              header: { 'content-type': 'application/json' },
              success: function (openIdRes) {
                sessionkey = openIdRes.data.data.sessionkey;
                console.log(openIdRes.data.data.sessionkey)
                that.globalData.sessionkey = openIdRes.data.data.session_key;
                openid = openIdRes.data.data.openid;
                that.globalData.openid = openIdRes.data.data.openid;
                console.log("我是onLaunch...success")
                // 判断openId是否获取成功
                if (openIdRes.data.data.openid != null & openIdRes.data.data.openid != undefined) {
                 // 有一点需要注意 询问用户 是否授权 那提示 是这API发出的
                 //获取姓名等信息
                  wx.getUserInfo({
                    success: function (data) {
                      console.log(data)
                      nickName = data.userInfo.nickName;
                      avatarUrl = data.userInfo.avatarUrl;
                      province = data.userInfo.province;
                      sex = data.userInfo.gender;
                      //将信息传给后台
                      wx.request({
                        url: 'https://www.everglamming.com/hrym-wechat-web/hrym/program/wechatUsersOPt',
                        // url: 'http://192.168.1.160:8080/hrym/program/wechatUsersOPt',
                        data:{
                          "cmd": "insertWechatUser",
                          "data":{
                            "openId": openid,
                            "nickName": nickName,
                            "avatarUrl": avatarUrl,
                            "province": province,
                            "sex": sex
                          },
                          "header":{
                            "appname":"慧修行",
                            "platform": platform,
                            "v": v
                          }     
                        },
                        method: 'post',
                        header: { 'content-type': 'application/json' },
                        success:function(res){
                          //网络回滚
                        
                          if (that.requestReadyCallback) {
                          
                            that.requestReadyCallback(res);
                          }
                          console.log("  //网络回滚")
                        },
                        fail: function (error) {
                          console.info("网络错误");
                          console.info(error);
                        }
                      })
              
                    },
                    fail: function (failData) {
                      console.info("用户拒绝授权");
                      wx.showModal({
                        title: '温馨提示',
                        content: '如不授权，将不能使用此功能',
                        success: function (res) {
                          if (res.confirm) {
                            console.log('用户点击确定')
                            wx.openSetting({
                              success: function (res) {
                                debugger
                                if (!res.authSetting["scope.userInfo"]) {
                                  debugger
                                  //这里是授权成功之后 填写你重新获取数据的js
                                  //参考:
                                  that.getLogiCallback('', function () {
                                    callback('')
                                  })
                                }
                              }
                            })
                          } else if (res.cancel) {
                            console.log('用户点击取消')
                          }
                        }
                      })  
                      // 
                    }
                  });  
                } else {
                  console.info("获取用户openId失败");
                }
                // 判断是什么渠道进入小程序
                if (ops.scene == 1044) {
                  console.log("我是微信群里进来的，快来取我ID啊！！！")
                  wx.getShareInfo({
                    shareTicket: ops.shareTicket,
                    complete(res) {
                      //将信息传给后台
                      wx.request({
                        url: 'https://www.everglamming.com/hrym-wechat-web/hrym/program/AesServiceController',
                        // url: 'http://192.168.1.160:8080/hrym/program/AesServiceController',
                        data: {
                          "cmd": "decryptAes",
                          "data": {
                            "openId": openid,
                            "sessionKey": sessionkey,
                            "encryptedData": res.encryptedData,
                            "iv": res.iv,
                          },
                          "header": {
                            "appname": "慧修行",
                            "platform": platform,
                            "v": v
                          }
                        },
                        method: 'post',
                        header: { 'content-type': 'application/json' },
                        success: function (res) {
                          console.log(res.data.data.msg)
                          that.globalData.openGId = res.data.data.openGId;
                        },
                        fail: function (error) {
                          console.info("网络错误");
                          console.info(error);
                        }
                      })

                    }
                  })
                }else{
                  that.globalData.openGId =null;
                  console.log(" that.globalData.openGId =null;")
                  console.log(that.globalData.openGId)
                }
              },
              
              fail: function (error) {
                console.info("获取用户openId失败");
                console.info(error);
              }
            })
          }
        }
      }); 
 
  },
  globalData: {
    sessionkey:"",
    openGId:"",
    openid:"",//用户登陆的openid
    //session_key:"",//用户登陆时候和openid一起获取下来的
    platform:"",//用户手机型号
    v:"",//用户手机版本号
    aeHttp: function (args, resolve, reject){
      let param = {
        url: "https://www.everglamming.com/hrym-wechat-web/hrym/program/",
          //  url: "http://192.168.1.160:8080/hrym/program/",
        // appkey: '609388a15b3dfaca',
        // masterKey: "",
      };
      wx.request({
        url: param.url + args.url,
        data: args.data,
        method: 'POST',
        success: function (res) {
          resolve(res);   
        },
        fail: function (err) {
          console.log(err)
          reject(err);
        }
      })
    }
  }
})